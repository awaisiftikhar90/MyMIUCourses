package edu.cs489.asdcs489finalexam2023.dto;

import edu.cs489.asdcs489finalexam2023.model.Account;
import edu.cs489.asdcs489finalexam2023.model.Customer;
import jakarta.validation.constraints.NotBlank;

import java.time.LocalDate;

public class AccountDTO {



    private Long accountId;
    @NotBlank(message = " Account No cannot be null, empty or blank")
    private String accountNumber;
    @NotBlank(message = " Account Type cannot be null, Empty or blank")
    private String accountType;
    private LocalDate dateOpened;
    @NotBlank(message = " Account Balance cannot be null, Empty or blank")
    private Double balance;

    private Account account;

}
