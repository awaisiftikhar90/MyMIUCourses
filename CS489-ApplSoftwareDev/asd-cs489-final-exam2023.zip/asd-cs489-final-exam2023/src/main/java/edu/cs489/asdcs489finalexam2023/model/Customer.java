package edu.cs489.asdcs489finalexam2023.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import edu.cs489.asdcs489finalexam2023.repository.CustomerRepository;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "customer")
public class Customer {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer customerId;
@Column(nullable = false)
@NotNull
private String firstName;
@Column(nullable = false)
@NotNull
private String lastName;
@JsonManagedReference
@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
private List<Account> accounts;

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

}
