package edu.cs489.asdcs489finalexam2023.Services.Imp;

import edu.cs489.asdcs489finalexam2023.Services.CustomerService;
import edu.cs489.asdcs489finalexam2023.model.Customer;
import edu.cs489.asdcs489finalexam2023.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CustomerServiceImp  {

private CustomerRepository customerRepository;

    public CustomerServiceImp(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }



    public Customer updateCustomerByCustomerId(Long customerId, Customer editedCustomer){
        var customer = customerRepository.findCustomerByCustomerId(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid CustomerId"));


        customer.setFirstName(editedCustomer.getFirstName());
        customer.setLastName(editedCustomer.getLastName());
        customer.setAccounts(editedCustomer.getAccounts());
        return customerRepository.save(customer);


    }
    public List<Customer> getProductList() {
        var products = customerRepository.findAll();
        return products;
    }

    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }
}
