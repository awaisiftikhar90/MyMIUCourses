package edu.cs489.asdcs489finalexam2023.controller;

import edu.cs489.asdcs489finalexam2023.Services.CustomerService;
import edu.cs489.asdcs489finalexam2023.Services.Imp.AccountServiceImp;
import edu.cs489.asdcs489finalexam2023.model.Account;
import edu.cs489.asdcs489finalexam2023.model.Customer;
import edu.cs489.asdcs489finalexam2023.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Comparator;
import java.util.List;

@RestController
@RequestMapping(value = {"/api/account"})
public class AccountController {


    private AccountRepository accountRepository;

    public AccountController(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @GetMapping("/list")
    public ResponseEntity<List<Account>> getProductsList(){
        return new ResponseEntity<>(accountRepository.findByBalanceGreaterThanEqual(0.0), HttpStatus.OK);
    }

    //Account Sorted
    @GetMapping("/deposit-accounts")
    public List<Account> getAllDepositAccountsSortedByBalance() {
        List<Account> depositAccounts = accountRepository.findByBalanceGreaterThanEqual(0.0);
        depositAccounts.sort(Comparator.comparing(Account::getBalance).reversed());
        return depositAccounts;
    }
    //
    @GetMapping("/sorted-by-balance-desc")
    public List<Account> getCustomersSortedByAccountBalanceDescending() {
        List<Account> accounts = accountRepository.findAll();
        accounts.sort(Comparator.comparingDouble(
                customer -> accounts.stream()
                        .mapToDouble(Account::getBalance)
                        .sum()
        ).reversed());
        return accounts;
    }
    @GetMapping("/api/accounts/prime-accounts")
    public List<Account> getPrimeAccounts() {
        List<Account> primeAccounts = accountRepository.findByBalanceGreaterThanEqual(100000.0);
        return primeAccounts;
    }



// GET:  http://localhost:8080/api/account/list
// GET:  http://localhost:8080/api/account/sorted-by-balance-desc
    // GET:  http://localhost:8080/api/account//deposit-accounts



}
