package edu.cs489.asdcs489finalexam2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsdCs489FinalExam2023Application {

    public static void main(String[] args) {
        SpringApplication.run(AsdCs489FinalExam2023Application.class, args);
    }

}
