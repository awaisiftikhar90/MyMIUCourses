package edu.cs489.asdcs489finalexam2023.Services.Imp;

import edu.cs489.asdcs489finalexam2023.Services.AccountService;
import edu.cs489.asdcs489finalexam2023.model.Account;
import edu.cs489.asdcs489finalexam2023.repository.AccountRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AccountServiceImp   {
 private AccountRepository accountRepository;

    public AccountServiceImp(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public List<Account> getAllCustomerSorted(){
        List<Account> sortedCustomers = accountRepository.findAll(Sort.by(Sort.Order.asc("balance")));
        return sortedCustomers;
    }

}
