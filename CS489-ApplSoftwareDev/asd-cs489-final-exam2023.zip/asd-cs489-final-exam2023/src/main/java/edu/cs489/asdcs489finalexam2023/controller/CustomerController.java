package edu.cs489.asdcs489finalexam2023.controller;

import edu.cs489.asdcs489finalexam2023.Services.Imp.CustomerServiceImp;
import edu.cs489.asdcs489finalexam2023.dto.CustomerDTO;
import edu.cs489.asdcs489finalexam2023.model.Customer;
import edu.cs489.asdcs489finalexam2023.repository.CustomerRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = {"/api/customer"})

public class CustomerController {


    private CustomerServiceImp customerServiceImp;

    public CustomerController(CustomerServiceImp customerServiceImp) {
        this.customerServiceImp = customerServiceImp;
    }

    @PutMapping(value = {"/update/{customerId}"})
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long customerId, @RequestBody Customer customer) {
        Customer p = customerServiceImp.updateCustomerByCustomerId(customerId, customer);
        return new ResponseEntity<>(p, HttpStatus.OK);
    }
//PUT:  http://localhost:8080/api/customer/update/1


    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        Customer newCustomer = customerServiceImp.createCustomer(customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(newCustomer);
    }

    //request to http://localhost:8080/api/customer
}
