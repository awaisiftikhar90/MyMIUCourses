package edu.cs489.asdcs489finalexam2023.repository;

import edu.cs489.asdcs489finalexam2023.model.Account;
import edu.cs489.asdcs489finalexam2023.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
    List<Account> findByBalanceGreaterThanEqual(double minBalance);


    @Query(value = " Select * from `finalexam-db`.account a where a.balance >= :customerId",nativeQuery = true)
    Optional<Account> getProductUsingProductNumber2(Long productNo);
}

