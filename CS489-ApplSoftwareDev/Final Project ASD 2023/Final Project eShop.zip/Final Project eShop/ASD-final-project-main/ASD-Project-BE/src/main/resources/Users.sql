/*
-- Query: SELECT * FROM eShop.users
*/
INSERT INTO users (`customer_id`,`email`,`password`,`phone_number`,`username`)
VALUES (2,'awais@miu.edu','awais','3239425222','Awais Iftikhar');
