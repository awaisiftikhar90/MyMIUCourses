package cs489.srmsamplefinalexam.Service;

import cs489.srmsamplefinalexam.model.Supplier;
import jakarta.persistence.GeneratedValue;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = {"/srmweb/api/supplier"})
public class SupplierController {

    private  SupplierService supplierService;

    public SupplierController(SupplierService supplierService) {
        this.supplierService = supplierService;
    }

    @GetMapping(value = {"/list"})
    public ResponseEntity<List<Supplier>> listSupplier(){
        return ResponseEntity.ok(supplierService.getAllSupplierSorted());
    }
    @GetMapping(value = {"/starsupplier/list"})
    public ResponseEntity<List<Supplier>> listStarSupplier(){
        return ResponseEntity.ok(supplierService.getStarSuppliers());
    }
}
