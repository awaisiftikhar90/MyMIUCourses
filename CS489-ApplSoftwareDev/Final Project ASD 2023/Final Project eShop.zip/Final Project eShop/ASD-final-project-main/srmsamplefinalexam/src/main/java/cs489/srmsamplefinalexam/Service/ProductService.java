package cs489.srmsamplefinalexam.Service;

import cs489.srmsamplefinalexam.model.Product;
import cs489.srmsamplefinalexam.repository.ProductRespository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    private ProductRespository productRespository;

    public ProductService(ProductRespository productRespository) {
        this.productRespository = productRespository;
    }
    public Product updateProductByProductNo(Long productNo, Product editedProdcut){
        var prodcut = productRespository.findProductByProductNo(productNo)
                .orElseThrow(() -> new IllegalArgumentException("Invalid ProductNo"));

             prodcut.setName(editedProdcut.getName());
             prodcut.setUnitPrice(editedProdcut.getUnitPrice());
             prodcut.setQuantityInStock(editedProdcut.getQuantityInStock());
             prodcut.setDateSupplied(editedProdcut.getDateSupplied());
             return productRespository.save(prodcut);


    }
    //4
    public List<Product> getProductList() {
        var products = productRespository.findAll();
        return products;
    }
}
