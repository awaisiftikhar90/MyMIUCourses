package cs489.srmsamplefinalexam.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "suppliers")

public class Supplier {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer supplierId;
@Column(nullable = false)
@NotBlank //notnull not empty or blank
    private String name;
    @Column(nullable = true)  //optional
    private String contactPhoneNumber;

    @JsonManagedReference
    @OneToMany(mappedBy = "supplier",fetch = FetchType.EAGER) //One supplier many products //MappedBy mean this table does Not contain foreing key
    private List<Product> products;

    public boolean isStarSupplier(){
        return  (this.products.size() >= 2 && totalProductsAmount() > 100000 );
    }

    private  Double totalProductsAmount(){
        return  products.stream()
                .mapToDouble(p -> p.getUnitPrice() * p.getQuantityInStock())
                .sum();
    }
}
