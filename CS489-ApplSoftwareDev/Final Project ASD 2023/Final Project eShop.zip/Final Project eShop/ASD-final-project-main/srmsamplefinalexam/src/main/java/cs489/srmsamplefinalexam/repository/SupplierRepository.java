package cs489.srmsamplefinalexam.repository;

import cs489.srmsamplefinalexam.model.Supplier;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.data.repository.ListPagingAndSortingRepository;

public interface SupplierRepository extends ListPagingAndSortingRepository<Supplier, Integer> {
}
