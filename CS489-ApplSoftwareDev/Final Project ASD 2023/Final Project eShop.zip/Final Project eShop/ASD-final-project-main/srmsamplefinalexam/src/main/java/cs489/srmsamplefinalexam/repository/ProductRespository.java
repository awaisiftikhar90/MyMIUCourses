package cs489.srmsamplefinalexam.repository;

import cs489.srmsamplefinalexam.model.Product;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.ListCrudRepository;

import java.util.Optional;

public interface ProductRespository  extends ListCrudRepository<Product,Long> {
    Optional<Product> findProductByProductNo(Long productNo);

    @Query(value = " select p from Product p where p.getProducNo = :productNo")
    Optional<Product> getProductUsingProductNumber(Long productNo);
    @Query(value = " select * from `dentissystem-db`.products p where  p.get_produc_no= :productNo",nativeQuery = true)
    Optional<Product> getProductUsingProductNumber2(Long productNo);
}
