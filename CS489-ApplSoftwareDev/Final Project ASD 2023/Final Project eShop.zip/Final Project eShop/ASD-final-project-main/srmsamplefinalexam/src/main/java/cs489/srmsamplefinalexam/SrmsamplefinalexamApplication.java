package cs489.srmsamplefinalexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrmsamplefinalexamApplication {

    public static void main(String[] args) {
        SpringApplication.run(SrmsamplefinalexamApplication.class, args);
    }

}
