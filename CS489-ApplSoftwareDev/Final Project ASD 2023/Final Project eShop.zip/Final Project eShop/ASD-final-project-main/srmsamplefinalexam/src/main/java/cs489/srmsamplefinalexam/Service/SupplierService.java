package cs489.srmsamplefinalexam.Service;

import cs489.srmsamplefinalexam.model.Supplier;
import cs489.srmsamplefinalexam.repository.SupplierRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SupplierService {

    //Dependency Injectioin for Supplier repository
    private SupplierRepository supplierRepository;

    public SupplierService(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    public List<Supplier> getAllSupplierSorted(){
        return supplierRepository.findAll(Sort.by("name"));
    }

    public  List<Supplier> getStarSuppliers(){
        return  supplierRepository.findAll(Sort.by("name"))
                .stream()
                .filter(s-> s.isStarSupplier())
                .toList();
    }
}

