package cs489.srmsamplefinalexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrmsamplefinalexamApplicationTests {

    @Test
    void contextLoads() {
    }

}
