package edu.cs489.asdcs489finalexam2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsdCs489FinalExam2023ApplicationTests {

    @Test
    void contextLoads() {
    }

}
