package edu.cs489.asdcs489finalexam2023.Services;

import edu.cs489.asdcs489finalexam2023.model.Account;
import edu.cs489.asdcs489finalexam2023.model.Customer;

import java.util.List;

public interface CustomerService {
    public abstract List<Customer> getAllAccount();
}
