package edu.cs489.asdcs489finalexam2023.dto;

import edu.cs489.asdcs489finalexam2023.model.Customer;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CustomerDTO {

    private Integer customerId;
    @NotBlank(message = " Customer First Name cannot be null, Empty or blank")
    private String firstName;
    @NotBlank(message = " Customer Last Name cannot be null, Empty or blank")
    private String lastName;
    private Customer customer;
}
