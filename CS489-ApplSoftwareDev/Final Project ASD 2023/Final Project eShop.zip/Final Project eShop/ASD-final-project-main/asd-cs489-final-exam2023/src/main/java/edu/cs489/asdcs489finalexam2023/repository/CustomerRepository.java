package edu.cs489.asdcs489finalexam2023.repository;

import edu.cs489.asdcs489finalexam2023.model.Account;
import edu.cs489.asdcs489finalexam2023.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CustomerRepository extends  JpaRepository<Customer, Long>  {
    Optional<Customer> findCustomerByCustomerId(Long customerId);

    @Query(value = " select c from Customer C where c.customerId = :customerId")
    Optional<Customer> getCustomerUsingCustomerId(Long customerId);

    @Query(value = " Select * from `finalexam-db`.account a where a.balance >= :customerId",nativeQuery = true)
    Optional<Account> getProductUsingProductNumber2(Long productNo);

}



