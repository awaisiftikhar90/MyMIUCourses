package edu.cs489.asdcs489finalexam2023.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "account")

public class Account {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private  Long accountId;
@Column(nullable = false, unique = true)
private String accountNumber;
@Column(nullable = false)
@NotNull
private  String accountType;
private LocalDate dateOpened;
@Column(nullable = false)
@NotNull
private  Double balance;
    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }
}
