package edu.cs489.asdcs489finalexam2023.Services;

import edu.cs489.asdcs489finalexam2023.model.Account;

import java.util.List;

public interface AccountService {
    public abstract List<Account> getAllAccount();
}
