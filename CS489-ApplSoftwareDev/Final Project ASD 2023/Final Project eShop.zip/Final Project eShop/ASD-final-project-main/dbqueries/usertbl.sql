/*
-- Query: SELECT * FROM eShop.users

*/
INSERT INTO users (`customer_id`,`email`,`password`,`phone_number`,`username`) VALUES (1,'test@gamil.com','testuser','7748392','Test User');

Select * from users
UPDATE users
SET email="awais@miu.edu" ,password="test123",username="Awais Iftikhar",phone_number=22225555445
WHERE customer_id=2;